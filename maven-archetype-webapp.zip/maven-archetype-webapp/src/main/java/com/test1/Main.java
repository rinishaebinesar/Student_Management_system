package com.test1;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.student.model.StudentMain;
import com.test.util.UtilHibernate;

public class Main {

    public static void main(String[] args) {

        SessionFactory sessionFactory = UtilHibernate.getSessionFactory();
        Session session = sessionFactory.openSession();

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter student name: ");
        String name = sc.nextLine();

        System.out.print("Enter department: ");
        String department = sc.nextLine();

        System.out.print("Enter age: ");
        int age = sc.nextInt();

        StudentMain student = new StudentMain(name, department, age);

        session.beginTransaction();

        session.persist(student);

        session.getTransaction().commit();

        session.close();
        sessionFactory.close();
        sc.close();

        System.out.println("Student data inserted successfully!");
    }
}