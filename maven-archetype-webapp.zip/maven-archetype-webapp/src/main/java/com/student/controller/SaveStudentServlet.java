package com.student.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.student.model.StudentMain;
import com.test.util.UtilHibernate;

@WebServlet("/saveStudent")
public class SaveStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        // Get values from HTML form
        String name = request.getParameter("name");
        String department = request.getParameter("department");
        int age = Integer.parseInt(request.getParameter("age"));

        // Open Hibernate session
        Session session = UtilHibernate.getSessionFactory().openSession();

        // Start transaction
        Transaction transaction = session.beginTransaction();

        // Create Student object
        StudentMain student = new StudentMain();
        student.setName(name);
        student.setDepartment(department);
        student.setAge(age);

        // Save student
        session.persist(student);

        // Commit transaction
        transaction.commit();

        // Close session
        session.close();

        // Response
        response.setContentType("text/html");
        response.getWriter().println("<h2>Student Saved Successfully!</h2>");
    }
}