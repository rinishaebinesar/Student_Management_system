package com.student.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.student.model.StudentMain;
import com.test.util.UtilHibernate;

@WebServlet("/updateStudent")
public class UpdateStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String department = request.getParameter("department");
        int age = Integer.parseInt(request.getParameter("age"));

        Session session = UtilHibernate.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        StudentMain student = session.get(StudentMain.class, id);

        if (student != null) {

            student.setName(name);
            student.setDepartment(department);
            student.setAge(age);

            transaction.commit();

            response.setContentType("text/html");
            response.getWriter().println("<h2>Student Updated Successfully!</h2>");

        } else {

            transaction.rollback();

            response.setContentType("text/html");
            response.getWriter().println("<h2>Student Not Found!</h2>");
        }

        session.close();
    }
}