package com.student.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.student.model.StudentMain;
import com.test.util.UtilHibernate;

@WebServlet("/viewStudents")
public class ViewStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        Session session = UtilHibernate.getSessionFactory().openSession();

        List<StudentMain> students =
                session.createQuery("from StudentMain", StudentMain.class)
                       .getResultList();

        session.close();

        response.setContentType("text/html");

        java.io.PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>View Students</title></head>");
        out.println("<body>");

        out.println("<h2>Student List</h2>");

        out.println("<table border='1' cellpadding='10'>");

        out.println("<tr>");
        out.println("<th>ID</th>");
        out.println("<th>Name</th>");
        out.println("<th>Department</th>");
        out.println("<th>Age</th>");
        out.println("</tr>");

        for (StudentMain student : students) {

            out.println("<tr>");

            out.println("<td>" + student.getId() + "</td>");
            out.println("<td>" + student.getName() + "</td>");
            out.println("<td>" + student.getDepartment() + "</td>");
            out.println("<td>" + student.getAge() + "</td>");

            out.println("</tr>");
        }

        out.println("</table>");

        out.println("</body>");
        out.println("</html>");
    }
}