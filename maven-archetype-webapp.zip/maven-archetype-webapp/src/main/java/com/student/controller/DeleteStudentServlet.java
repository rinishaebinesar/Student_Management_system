package com.student.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.student.model.StudentMain;
import com.test.util.UtilHibernate;

@WebServlet("/deleteStudent")
public class DeleteStudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));

        Session session = UtilHibernate.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        StudentMain student = session.get(StudentMain.class, id);

        if (student != null) {

            session.remove(student);

            transaction.commit();

            response.setContentType("text/html");
            response.getWriter().println(
                "<h2>Student Deleted Successfully!</h2>"
            );

        } else {

            transaction.rollback();

            response.setContentType("text/html");
            response.getWriter().println(
                "<h2>Student Not Found!</h2>"
            );
        }

        session.close();
    }
}